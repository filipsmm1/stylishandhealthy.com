# Stylish and Healthy — Site Files

## Deploy to GitHub Pages

1. Create a new GitHub repo (e.g. `stylish-and-healthy`)
2. Upload all these files, keeping the folder structure exactly as-is
3. Go to **Settings → Pages → Source → Deploy from branch → main / root**
4. Your site will be live at `https://yourusername.github.io/stylish-and-healthy`

---

## File Map

```
stylish-and-healthy/
│
├── index.html                  ← Homepage
├── about.html                  ← About page
├── _config.yml                 ← GitHub Pages config (keep this)
│
├── css/
│   └── style.css               ← ALL styles — design system, layout, components
│
├── js/
│   └── main.js                 ← ALL behaviour — cursor, nav, scroll, parallax
│
├── blog/
│   ├── index.html              ← Blog archive with category filter
│   ├── morning-routine.html    ← Article template (copy for every new post)
│   ├── retinol-guide.html      ← (create from template)
│   ├── sleep-protocol.html     ← (create from template)
│   ├── sunscreen-edit.html     ← (create from template)
│   ├── journal-practice.html   ← (create from template)
│   ├── cold-water.html         ← (create from template)
│   └── nutrition-non-rules.html← (create from template)
│
├── shop/
│   ├── index.html              ← Shop/product listing page
│   ├── skin-journal.html       ← Product detail (full template)
│   ├── wellness-planner.html   ← (copy from skin-journal.html, edit content)
│   └── morning-guide.html      ← (copy from skin-journal.html, edit content)
│
└── assets/
    └── og-image.jpg            ← Social share image (1200×630, parchment bg)
```

---

## Adding a New Blog Post

Copy `blog/morning-routine.html` and:
1. Change `<title>` and `<meta name="description">`
2. Update `<h1>` headline
3. Update the `.t-eyebrow` category label
4. Update `.article-meta` (author, date, read time)
5. Replace the hero `<img src>` with your image
6. Replace the article body paragraphs, h2s, and pull quotes
7. Update the three related article cards at the bottom
8. Add a link to it in `blog/index.html`'s grid with the right `data-category`

---

## Replacing Unsplash Images

All `<img src>` values currently point to Unsplash for placeholder content.
Replace with your own images — ideally hosted in `/assets/images/`.

Recommended sizes:
- Hero: 1600×900px minimum
- Article hero: 1200×675px
- Blog card (large): 800×600px
- Blog card (small): 600×340px
- Product card: 600×900px
- About portrait: 600×800px

All images automatically get the brand CSS filter treatment:
`filter: contrast(1.05) saturate(0.88) sepia(0.07) brightness(0.97)`

---

## Connecting a Payment Provider (Shop)

In `shop/skin-journal.html` (and the other product pages), find this function:
```js
function handlePurchase(e) {
  e.preventDefault();
  // Replace with your payment link
}
```

Replace with a redirect to your Gumroad, LemonSqueezy, or Stripe payment link:
```js
function handlePurchase(e) {
  e.preventDefault();
  window.location.href = 'https://your-gumroad-link.gumroad.com/l/product-id';
}
```

---

## Connecting a Newsletter Provider

The newsletter form currently shows a confirmation message on submit.
To connect Mailchimp, ConvertKit, or similar:
1. Get your form's POST action URL from your provider
2. In `js/main.js`, replace the `newsletterForm` event listener with a fetch POST
3. Or simply replace the `<form>` with your provider's embed code, styled to match

---

## Fonts

Loaded from Google Fonts in `css/style.css`:
- Cormorant Garamond (300, 400, 500 — regular and italic)
- Bebas Neue
- Inter (300, 400, 500)

For faster loading, download and self-host them in `/assets/fonts/`.

---

## Notes

- No white backgrounds. `var(--parchment)` (#F5EFE0) and `var(--ivory)` (#FAF6EE) only.
- No rounded corners on images or cards. Rectangular only.
- No drop shadows. Depth comes from background color difference.
- The custom cursor hides automatically on touch devices.
- All animations respect `prefers-reduced-motion`.
