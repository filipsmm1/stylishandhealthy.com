/* ============================================================
   STYLISH AND HEALTHY — MAIN JS
   js/main.js
   ============================================================ */

// ── CUSTOM CURSOR ──────────────────────────────────────────
const cursor = document.getElementById('cursor');
let cursorX = 0, cursorY = 0, rafId;

if (cursor && !('ontouchstart' in window)) {
  document.addEventListener('mousemove', e => {
    cursorX = e.clientX;
    cursorY = e.clientY;
    if (!rafId) rafId = requestAnimationFrame(moveCursor);
  });

  function moveCursor() {
    cursor.style.left = cursorX + 'px';
    cursor.style.top  = cursorY + 'px';
    rafId = null;
  }

  document.querySelectorAll('a, button, [role="button"], input, .card, .product-card').forEach(el => {
    el.addEventListener('mouseenter', () => cursor.classList.add('cursor--hover'));
    el.addEventListener('mouseleave', () => cursor.classList.remove('cursor--hover'));
  });
} else if (cursor) {
  cursor.style.display = 'none';
}

// ── NAVBAR ──────────────────────────────────────────────────
const nav = document.getElementById('nav');
if (nav) {
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 40);
  }, { passive: true });
}

// ── MOBILE MENU ──────────────────────────────────────────────
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobile-menu');
const closeMenu  = document.getElementById('close-menu');

if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => {
    mobileMenu.classList.add('open');
    document.body.style.overflow = 'hidden';
    hamburger.setAttribute('aria-expanded', 'true');
  });
  const closeFn = () => {
    mobileMenu.classList.remove('open');
    document.body.style.overflow = '';
    hamburger.setAttribute('aria-expanded', 'false');
  };
  if (closeMenu) closeMenu.addEventListener('click', closeFn);
  mobileMenu.addEventListener('click', e => {
    if (e.target === mobileMenu) closeFn();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeFn();
  });
}

// ── HERO PARALLAX ────────────────────────────────────────────
const heroImg = document.querySelector('.hero-img');
if (heroImg) {
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        const y = window.scrollY;
        heroImg.style.transform = `translateY(${y * 0.4}px)`;
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });
}

// ── INTERSECTION OBSERVER (reveal + gold lines) ───────────────
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

// Gold lines
const lineObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('animate');
      lineObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.gold-line, .manifesto-line-top, .manifesto-line-bottom').forEach(el => {
  lineObserver.observe(el);
});

// ── READING PROGRESS ─────────────────────────────────────────
const progressFill = document.querySelector('.reading-progress-fill');
const articleBody  = document.querySelector('.article-body');

if (progressFill && articleBody) {
  window.addEventListener('scroll', () => {
    const rect = articleBody.getBoundingClientRect();
    const total = articleBody.offsetHeight;
    const scrolled = -rect.top + window.innerHeight * 0.5;
    const pct = Math.min(100, Math.max(0, (scrolled / total) * 100));
    progressFill.style.height = pct + '%';
  }, { passive: true });
}

// ── FLOATING NEWSLETTER LABEL ─────────────────────────────────
const newsletterInput = document.getElementById('newsletter-email');
const newsletterLabel = document.getElementById('newsletter-label');

if (newsletterInput && newsletterLabel) {
  const float = () => {
    if (newsletterInput.value || document.activeElement === newsletterInput) {
      newsletterLabel.classList.add('float');
    } else {
      newsletterLabel.classList.remove('float');
    }
  };
  newsletterInput.addEventListener('focus', float);
  newsletterInput.addEventListener('blur', float);
  newsletterInput.addEventListener('input', float);
}

// ── NEWSLETTER FORM ──────────────────────────────────────────
const newsletterForm = document.getElementById('newsletter-form');
if (newsletterForm) {
  newsletterForm.addEventListener('submit', e => {
    e.preventDefault();
    const email = document.getElementById('newsletter-email').value;
    if (email) {
      newsletterForm.innerHTML = `
        <p style="font-family: var(--font-serif); font-style: italic; font-size: 22px; color: var(--parchment); opacity: 0.85;">
          You're in. See you in your inbox.
        </p>`;
    }
  });
}

// ── ACTIVE NAV LINK ──────────────────────────────────────────
const currentPath = window.location.pathname;
document.querySelectorAll('.nav-links a').forEach(link => {
  if (link.getAttribute('href') && currentPath.includes(link.getAttribute('href'))) {
    link.classList.add('active');
  }
});
